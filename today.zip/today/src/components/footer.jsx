import React, { Component } from "react";

  class Footer extends Component {
    constructor(props) {
      super(props);
      this.state = {}
        
        
      };
      
      componentDidMount() {

        

      }
  
    render() {
    

     return (
      
        <footer>
          <div className="">Copyright@2019, THG PUBLISHING PVT LTD.</div>
        </footer>
        
      ); 
      
     
    }
  
  }
  
  
  export default Footer;
