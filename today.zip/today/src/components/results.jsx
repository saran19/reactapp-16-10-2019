
import React, { Component } from "react";
import axios from "axios";
import {CopyToClipboard} from "react-copy-to-clipboard";
import { FacebookShareButton, TwitterShareButton,WhatsappShareButton,FacebookIcon,TwitterIcon,WhatsappIcon} from "react-share";
import { Helmet } from 'react-helmet';

class Results extends Component {
    constructor(props) {
      super(props);
       
      this.state = {
        id:String,
        arID :String,
        listDataArticle:[]
  
        }
        this.getresults = this.getresults.bind(this);
    
      };
      componentDidMount() {
        this.state.arID = this.props.name.match.params.id;
        this.setState({arID : this.state.arID});
        this.getresults();
        
      }
    
     async  getresults() {
      axios.defaults.withCredentials = false;
   await axios.get("https://alphath.thehindu.co.in/app/getArticleByIds.json?articleIds="+this.state.arID+"").then(response=>{
        
        this.state.listDataArticle.push(response.data);
        this.setState({ listDataArticle: this.state.listDataArticle });
      })
  
    }
    
    togglefun(){ 
		  var x = document.getElementById("myDIV");
	  if (x.style.display === "none") {
		x.style.display = "block";
	  } else if (x.style.display === "block") {
		x.style.display = "none";
	  }else { console.log("in");
		x.style.display = "block";
	  }
    } 

    render() {
  
      return (
        
<div className="container">
	<div className="blog-page-main">
	  <h1 className="blog-title-top">Clude In</h1>
	</div>
	<div className="row">
  {this.state.listDataArticle.length>0?(
    <section>
      {this.state.listDataArticle[0].data.map((article,index)=>(
		<div className="blog-pg-block article-pg" key={article}>
          <title>{article.ti}</title>
          <meta property="og:url" content="https://alphath.thehindu.co.in/" />
          <meta property="og:title" content="Breaking News, India News, Elections, Bollywood, Cricket, Video, Latest News &amp; Live Updates" />
          <meta property="og:description" content={article.au} />
          <meta property="og:image" content={article.me[0].im} />
          <meta property="og:image:type" content="image/jpeg" />

			<div className="col-sm-12 col-xs-12 col-lg-12 col-md-12">
				<h3 className="blog-article-title">{article.ti}</h3>
					<div className="author-name-article"><span>{article.au}</span>&nbsp;|&nbsp;<span className="date-blog"> {article.pd}</span></div>


          <div className="item">
                <div className="share-alt"><div className="hidden-lg hidden-md visible-xs hidden-sm">
               <a onClick={()=>this.togglefun()} > <i className="fa fa-share-alt alt"> </i> </a>
                </div></div> 
                
                <span className="pull-right shre-alts sample" id="myDIV">
                  
                <div className="social-icon-blog" data-id="1"> 
            
                <FacebookShareButton
                  url={window.location.href}
                  quote={article.ti}
                  className="icon-button facebook">
                  <FacebookIcon
                    size={25}
                    round />
                  </FacebookShareButton>
                
                <TwitterShareButton
                  url={window.location.href}
                  title={article.ti}
                  className="icon-button twitter">
                  <TwitterIcon
                    size={25}
                    round />
                  </TwitterShareButton>

                  <WhatsappShareButton
                url={window.location.href}
                title={article.ti}
                separator=":: "
                className="icon-button whatsapp">
                <WhatsappIcon size={25} round />
                </WhatsappShareButton>

                <CopyToClipboard text={window.location.href}
              onCopy={() => this.setState({copied: true})}>
                  <a className="icon-button link"><i className="fa fa-link"></i><span></span></a>
                </CopyToClipboard>
                
               
            </div></span> 
            </div>


						<div className="blog-article-img hidden-xs hidden-sm visible-lg visible-md">
							<img src={article.me[0].im} data-src-template={article.me[0].im} alt="A view of Alfa Serene Apartments at Maradu, located on the banks of Kochi backwaters on May 14, 2019." title="A view of Alfa Serene Apartments at Maradu, located on the banks of Kochi backwaters on May 14, 2019." className="lead-img adaptive placeholder" />
						</div>
						<div className="blog-article-img  visible-xs visible-sm hidden-lg hidden-md">
							<img src={article.me[0].im}data-src-template={article.me[0].im} alt="" title="" className="lead-img adaptive placeholder" />
						</div>

            <div dangerouslySetInnerHTML={{__html: `${article.de}`}} />

						
					<div> 
			</div>
		</div>
		 </div>
    ))}
     </section>
    ):([])}
		</div>
	</div>

        
      );
    }
  
  }
  
  export default Results;
